<!DOCTYPE html>
<html lang="en">
<head>
   <title>Listing</title>

    <link href="/css/fontawesome.min.css"  rel="stylesheet">
    <link  href="/css/listings.css"  rel="stylesheet">
    <link  href="/css/all.css"  rel="stylesheet">
    <link href="/css/all.min.css"  rel="stylesheet">

</head>
<body>
    <div class="navbar">
        <a href="/"><img src="/images/logo3.png" title="BARA-C RENTALS"  class="logo"/></a>
        <div class="links">

        </div>
    </div>
    <?php $__currentLoopData = $selected_item['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="heading">
        <h2><?php echo e($item->propertyname); ?></h2>
    </div>
    <div class="container">
        <div class="title">
            <h2><?php echo e($item->Room_Type); ?></h2>
        </div>
        <div class="content">
           <div class="main-image">
            <?php $img=json_decode($item->images) ?>
            
            <img src="<?php echo e(asset('/uploads/'.$img[0])); ?>" alt="SAMPLE IMAGE" >
           </div>
            <div class="description">
                <h3>Vacancies: 1 </h3>
                <h3>Rental Cost: Ksh <?php echo e(number_format($item->cost)); ?> </h3>
                <h3>Additional Costs: none</h3>
                <h3>Contact: <?php echo e($item->contact); ?></h3>
                
                

                
                

                

            </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="samples">
            <?php    foreach (json_decode( $item->images) as $image) { ?>

            <img src="<?php echo e(asset('/uploads/'.$image)); ?>" alt="SAMPLE IMAGE" class="sample-image">
            <?php }   ?>
        </div>
    </div>

    <div class="copy">
        <p>© <?php echo date('Y') ?> BARATON . All Rights Reserved | Design by <a href="index.php">Emmanuel Kiptoo And Kelvin Agoi</a> </p>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Baraton-Laravel\Baraton-Laravel\resources\views//selecteditem.blade.php ENDPATH**/ ?>